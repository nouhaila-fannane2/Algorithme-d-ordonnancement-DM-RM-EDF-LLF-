import os

from flask import Flask, request, render_template

app = Flask(__name__)


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def results():
    algo = request.form['algo']
    print(algo)


    ARR0 = request.form['ARR0']
    ARR1 = request.form['ARR1']
    ARR2 = request.form['ARR2']

    BT0 = request.form['BT0']
    BT1 = request.form['BT1']
    BT2 = request.form['BT2']

    P0 = request.form['P0']
    P1 = request.form['P1']
    P2 = request.form['P2']

    D0 = request.form['D0']
    D1 = request.form['D1']
    D2 = request.form['D2']

    tasks = '' + str(P0) + ' ' + str(ARR0) + ' ' + str(BT0) + ' ' + str(D0) + ' ' 'Task1' + '\n' + str(P1) + ' ' + str(
        ARR1) + ' ' + str(BT1) + ' ' + str(D1) + ' ' 'Task2''\n' \
            + str(P2) + ' ' + str(ARR2) + ' ' + str(BT2) + ' ' + str(D2) + ' ' 'Task3' ''

    output = open('tasks.txt', 'w')
    output.write(tasks)
    output.close()

    # return render_template('index.html', algo=algo)
    if algo == "RM":
        os.system('python templates/rm.py')
        return render_template('rm.html')
    elif algo == "DM":
        os.system('python templates/dm.py')
        return render_template('dm.html')
    elif algo == "LLF":
        os.system('python templates/llf.py')
        return render_template('llf.html')
    elif algo == "EDF":
        os.system('python templates/edf.py')
        return render_template('edf.html')


app.run(port=8200, debug=True)
