# STR-Algorithm-Scheduling

Le programme suivant nous permet de simuler les algorithmes STR ( RM, DM, EDF, LLF ) avec du code python sous l'IDE PYCHARM.
Le programme permet de choisir l'algorithme du systeme temps réel, d'entrer les valeurs de la simulation : Temps d'arrivée, Burst Time, Périodes, et Deadlines, ces valeurs sont stockés dans un fichier tasks.txt uilisé par la suite pour simuler l'algorithme choisi et puis le serveur Flask génére le diagramme de Gantt de l'algorithme.

  La variable algo stocke l'algorithme choisi 
  
<img width="263" alt="Capture" src="https://user-images.githubusercontent.com/70923734/107164053-646c2600-69ad-11eb-8f6f-cbc8d0bada5f.PNG">
<img width="329" alt="mm" src="https://user-images.githubusercontent.com/70923734/107164103-c462cc80-69ad-11eb-89db-8830c2d2e9cc.PNG">

   Selon l'algorithme choisi os.system permet d'exécuter le programme convenale et d'afficher template générés avec ce programme.
<img width="415" alt="m" src="https://user-images.githubusercontent.com/70923734/107164083-8d8cb680-69ad-11eb-97e3-04adfe411c6f.PNG">

![Sans titre (1)](https://user-images.githubusercontent.com/70923734/107163627-f0c91980-69aa-11eb-9cf0-276aade95f8a.gif)
